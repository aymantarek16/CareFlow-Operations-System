import { createClient } from "@supabase/supabase-js";

export default async function handler(req, res) {
  try {
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;

    const supabaseKey =
      process.env.SUPABASE_SERVICE_ROLE_KEY ||
      process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;

    if (!supabaseUrl || !supabaseKey) {
      return res.status(500).json({
        ok: false,
        message: "Missing Supabase environment variables",
        hasUrl: Boolean(supabaseUrl),
        hasKey: Boolean(supabaseKey),
      });
    }

    const supabase = createClient(supabaseUrl, supabaseKey);

    const { error } = await supabase
      .from("activity_logs")
      .select("id")
      .limit(1);

    if (error) {
      return res.status(500).json({
        ok: false,
        message: "Supabase ping failed",
        table: "activity_logs",
        error: error.message,
      });
    }

    return res.status(200).json({
      ok: true,
      message: "CareFlow is alive",
      table: "activity_logs",
      time: new Date().toISOString(),
    });
  } catch (error) {
    return res.status(500).json({
      ok: false,
      message: "Unexpected error",
      error: error.message,
    });
  }
}