select now();
